public class Mailinfo {
    public Client client;
    public String mailCod;
    public Mailinfo(String name_of_client,int age_of_client,String sex_of_client,String info,String type_of_Mail) {
        client = new Client(name_of_client,age_of_client,sex_of_client,info);
        mailCod = type_of_Mail;
    }
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append(client.getName()).append(" ");
        str.append(client.getSex()).append(" ");
        str.append(client.getOther_information()).append(" ");
        return str.toString();
    }
}

