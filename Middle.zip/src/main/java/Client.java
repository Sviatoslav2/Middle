public class Client {
    private String name;
    private int age;
    private String sex;
    private String other_information;
    public Client(String name_of_client,int age_of_client,String sex_of_client,String info){
        name = name_of_client;
        age = age_of_client;
        sex = sex_of_client;
        other_information = info;
    }
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }

    public String getOther_information() {
        return other_information;
    }

    public String getSex() {
        return sex;
    }

}
