public class MailSender {

    private boolean isAgeValid(Mailinfo info){
        if(info.client.getAge() > 18){
            return true;
        }
        else{
            return false;
        }
    }
    private boolean isSexValid(Mailinfo info){
        if(info.client.getSex() == "W" || info.client.getSex() == "M"){
            return true;
        }
        else {
            return false;
        }
    }
    public void sendMail(Mailinfo info){
        if (isAgeValid(info)&&isSexValid(info)){
        System.out.print(info.toString());
        }
    }
}


