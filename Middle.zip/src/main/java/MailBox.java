import java.util.ArrayList;

public class MailBox {
    public MailSender sender;
    public ArrayList<Mailinfo> box = new ArrayList<Mailinfo>();
    public void addMail(Mailinfo lst){
        box.add(lst);
    }
    public void sendAll(){
        for(int i = 0;i<box.size(); i++){
            sender.sendMail(box.get(i));
        }
    }

}

